package Productsearch;

public class Node  {
    String name;
    int proID,jumlah,hpro;
     Node leftchild,rightchild;
}
