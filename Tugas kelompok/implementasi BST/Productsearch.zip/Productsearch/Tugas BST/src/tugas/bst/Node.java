package tugas.bst;

public class Node  {
    String name;
    int nip,masa_kerja,gaji;
     Node leftchild,rightchild;
}
